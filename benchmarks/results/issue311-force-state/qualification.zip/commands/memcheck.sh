#!/usr/bin/env bash
set -euo pipefail
cd /home/jzzeng/codes/vibeqc-issue-310-setup
[[ -n "$SLURM_JOB_ID" && -n "$CUDA_VISIBLE_DEVICES" ]]
printf 'Slurm job: %s\n' "$SLURM_JOB_ID"
export PYTHONPATH=.:python
export OMP_NUM_THREADS=1
export OPENBLAS_NUM_THREADS=1
export VIBEQC_LIBRARY=$PWD/build/cuda/libvibeqc.so
export VIBEQC_RESOURCE_CUDA_TEST=1
/home/jzzeng/codes/vibeqc-issue-310/.venv/bin/python - <<'PY'
import ctypes, hashlib, json, os, subprocess
from pathlib import Path
from vibeqc.autotune import source_identity
p=Path(os.environ['VIBEQC_LIBRARY']).resolve()
lib=ctypes.CDLL(str(p));lib.vibeqc_get_source_identity.restype=ctypes.c_char_p
identity=lib.vibeqc_get_source_identity().decode()
assert identity==source_identity(Path.cwd())
a={'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
'native_scientific_source_identity':identity,'native_library_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),
'slurm_job_id':os.environ['SLURM_JOB_ID'],'cuda_visible_devices':os.environ['CUDA_VISIBLE_DEVICES']}
Path('/tmp/vibeqc-311-force-native-identity.json').write_text(json.dumps(a,indent=2)+'\n')
print(a)
PY
/group/software/cuda-12.9.1/bin/compute-sanitizer --tool memcheck --leak-check full --error-exitcode 99 /home/jzzeng/codes/vibeqc-issue-310/.venv/bin/python -m pytest -q 'tests/python/test_df_final_state_cuda.py::test_selection_rebuild_and_force_transitions[0-1-cartesian-rhf]' 'tests/python/test_df_final_state_cuda.py::test_selection_rebuild_and_force_transitions[8388608-4-spherical-uhf]' 'tests/python/test_df_final_state_cuda.py::test_complete_force_matches_independent_energy_differences[empty_beta-cartesian]' --basetemp=/tmp/vibeqc-311-force-memcheck-traces > /tmp/vibeqc-311-force-endpoint-memcheck.log 2>&1
/group/software/cuda-12.9.1/bin/compute-sanitizer --tool memcheck --leak-check full --error-exitcode 99 build/cuda/vibeqc_df_eigensystem_tests > /tmp/vibeqc-311-force-export-memcheck.log 2>&1
