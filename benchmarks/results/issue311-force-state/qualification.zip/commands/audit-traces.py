"""Check every current qualification trace before retaining its original bytes."""
from pathlib import Path
from collections import defaultdict, Counter
import json
from benchmarks.df_component_ledger import read_host_trace, aggregate_host
root=Path('/tmp/vibeqc-311-force-selection-traces')
paths=sorted(p for p in root.glob('*/*.jsonl') if not p.parent.is_symlink())
assert len(paths)==240,len(paths)
summary=defaultdict(list)
for path in paths:
 records=read_host_trace(path)
 a=aggregate_host(records);p=a['exclusive_phases']
 count=lambda name:p.get(name,{}).get('calls',0)
 items=count('final_state_read');corrections=count('strict_final_correction')
 assert items in (1,4)
 assert count('final_state_fock_build')==count('final_state_validation')==items+corrections
 assert count('final_state_reuse')+count('final_state_corrected')==items
 assert count('final_state_weighted_density')==count('force_response')
 step,mode=path.stem.split('-',1)
 ref=a['eigensolves_by_reason'].get('final_fock',{}).get('calls',0)
 dev=a['device_eigensolves_by_reason'].get('final_fock',{}).get('calls',0)
 if mode=='reference_rebuild': assert ref>=items and dev==0
 else: assert ref==0
 if mode!='reuse': assert corrections>=items and count('final_state_reuse')==0
 assert ref+dev in (corrections,2*corrections)
 sources={(i,r['item']) for i,record in enumerate(records) for r in record['regions'] if r['name']=='final_state_read'}
 per_item=Counter((i,r['item']) for i,record in enumerate(records) for r in record['regions'] if r['name']=='strict_final_correction')
 assert len(sources)==items
 summary[(int(step),mode)].extend(per_item[item] for item in sources)
rows=[{'step':k[0],'selection':k[1],'minimum_joint_corrections_per_item':min(v),'maximum_joint_corrections_per_item':max(v)} for k,v in sorted(summary.items())]
path=Path('/tmp/vibeqc-311-force-export.jsonl')
cases=[r for r in read_host_trace(path) if r['regions'][0]['name'].startswith('test_cuda_export_')]
assert len(cases)==16
exports=[]
for r in cases:
 a=aggregate_host([r]);name=r['regions'][0]['name'];p=a['exclusive_phases']
 count=lambda name:p.get(name,{}).get('calls',0)
 actual=lambda key,reason:a[key].get(reason,{}).get('calls',0)
 ref=actual('eigensolves_by_reason','final_fock');dev=actual('device_eigensolves_by_reason','final_fock')
 assert count('final_state_read')==count('reference_export')==1
 assert actual('eigensolves_by_reason','reference_export')==actual('device_eigensolves_by_reason','reference_export')==0
 assert count('final_state_fock_build')==count('final_state_validation')==1+ref+dev
 assert count('strict_final_correction')==ref+dev
 assert count('final_state_weighted_density')==count('force_response')
 if 'reference_rebuild' in name: assert ref>=1 and dev==0
 elif 'device_rebuild' in name: assert dev>=1 and ref==0
 elif 'retained' in name: assert dev==ref==0 and count('final_state_reuse')==1
 else: assert ref==0
 exports.append({'case':name,'physical_fock_evaluations':count('final_state_fock_build'),'reference_solves':ref,'device_solves':dev,'weighted_density_constructions':count('final_state_weighted_density')})
result={'selection_trace_count':len(paths),'joint_corrections':rows,'export_cases':exports}
Path('/tmp/vibeqc-311-force-count-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
