#!/usr/bin/env bash
set -euo pipefail
cd /home/jzzeng/codes/vibeqc-issue-310
[[ -z $(git status --porcelain) ]]
export PYTHONPATH=python
export OMP_NUM_THREADS=1
export OPENBLAS_NUM_THREADS=1
cmake --build build/cuda --target vibeqc vibeqc_df_eigensystem_tests -j 6 > /tmp/vibeqc-310-cuda4-rebuild.log 2>&1
export VIBEQC_LIBRARY=$PWD/build/cuda/libvibeqc.so
export VIBEQC_RESOURCE_CUDA_TEST=1
export VIBEQC_TEST_FOCK_DEVICE=cuda
.venv/bin/python -m pytest -q tests/python/test_df_final_eigen_cuda.py tests/python/test_df_host_trace.py tests/python/test_hf_resources_cuda.py tests/python/test_fock.py tests/python/test_df_resources.py tests/python/test_df_occupied_cuda.py > /tmp/vibeqc-310-gpu4-python.log 2>&1
/group/software/cuda-12.9.1/bin/compute-sanitizer --tool memcheck --leak-check full --error-exitcode 99 build/cuda/vibeqc_df_eigensystem_tests > /tmp/vibeqc-310-gpu4-memcheck.log 2>&1
