#include <cuda_runtime.h>
#include <cusolverDn.h>
#include <cstdint>
#include <iostream>
int main() {
  cusolverDnHandle_t handle{}; cusolverDnParams_t parameters{};
  if (cusolverDnCreate(&handle) || cusolverDnCreateParams(&parameters)) return 1;
  for (int n : {1,2,6,12,32,64,96,128,192,256,384,513,768,1024,1536}) {
    double *a{}, *w{};
    if (cudaMalloc(reinterpret_cast<void**>(&a), std::size_t(n)*n*sizeof(double)) || cudaMalloc(reinterpret_cast<void**>(&w), n*sizeof(double))) return 2;
    std::size_t device{}, host{};
    const auto status = cusolverDnXsyevd_bufferSize(handle, parameters, CUSOLVER_EIG_MODE_VECTOR, CUBLAS_FILL_MODE_LOWER, std::int64_t(n), CUDA_R_64F, a, std::int64_t(n), CUDA_R_64F, w, CUDA_R_64F, &device, &host);
    std::cout << "{\"nbf\":" << n << ",\"status\":" << int(status) << ",\"device_bytes\":" << device << ",\"host_bytes\":" << host << "}\n";
    cudaFree(a); cudaFree(w);
    if (status) return 3;
  }
  cusolverDnDestroyParams(parameters); cusolverDnDestroy(handle);
}
