#!/usr/bin/env bash
set -euo pipefail
cd /home/jzzeng/codes/vibeqc-issue-308
export PYTHONPATH=python
export OMP_NUM_THREADS=1
export OPENBLAS_NUM_THREADS=1
for probe_domain in 96b4 192b1; do
  if [[ "$probe_domain" == 96b4 ]]; then
    probe_case=water-tetramer-def2-svp-spherical
    probe_batch=4
  else
    probe_case=water-octamer-s4-def2-svp-spherical
    probe_batch=1
  fi
  for probe_slice in lazy-core overlap-cache combined; do
    for probe_kind in profiled energy force; do
      probe_options=()
      if [[ "$probe_kind" != force ]]; then probe_options+=(--energy-only); fi
      if [[ "$probe_kind" == profiled ]]; then
        probe_options+=(--host-trace-dir "/tmp/vibeqc-309-cache-larger-$probe_domain-$probe_slice-traces")
      fi
      .venv/bin/python benchmarks/issue206_df_matrix.py --run --host-workloads \
        --preparation-ablation "$probe_slice" --case "$probe_case" --batch "$probe_batch" \
        --library build/cuda/libvibeqc.so --memory-budget-bytes 1073741824 --repeats 5 \
        "${probe_options[@]}" --output-dir "/tmp/vibeqc-309-cache-larger-$probe_domain-$probe_slice-$probe_kind"
    done
  done
done
