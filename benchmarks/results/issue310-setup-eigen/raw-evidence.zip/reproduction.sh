#!/usr/bin/env bash
set -euo pipefail
cd /home/jzzeng/codes/vibeqc-issue-310-setup
export PYTHONPATH=.:python
export OMP_NUM_THREADS=1
export OPENBLAS_NUM_THREADS=1
/home/jzzeng/codes/vibeqc-issue-310/.venv/bin/python - <<'IDENTITY'
from pathlib import Path
from hashlib import sha256
import ctypes,json,subprocess,os
from vibeqc.autotune import source_identity
root=Path.cwd()
assert os.environ['SLURM_JOB_ID'] and os.environ['CUDA_VISIBLE_DEVICES']
assert not subprocess.check_output(['git','status','--porcelain'],text=True)
path=(root/'build/cuda/libvibeqc.so').resolve()
lib=ctypes.CDLL(str(path));lib.vibeqc_get_source_identity.restype=ctypes.c_char_p
identity=lib.vibeqc_get_source_identity().decode()
assert identity==source_identity(root),(identity,source_identity(root))
record={'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
        'native_scientific_source_identity':identity,'native_library_sha256':sha256(path.read_bytes()).hexdigest(),
        'slurm_job_id':os.environ['SLURM_JOB_ID']}
Path('/tmp/vibeqc-310-setup-native-identity.json').write_text(json.dumps(record,indent=2)+'\n')
print(record)
IDENTITY
for probe_domain in 96b1 96b4 192b1; do
  probe_case=water-tetramer-def2-svp-spherical
  probe_batch=1
  if [[ "$probe_domain" == 96b4 ]]; then probe_batch=4; fi
  if [[ "$probe_domain" == 192b1 ]]; then probe_case=water-octamer-s4-def2-svp-spherical; fi
  for probe_kind in profiled energy force; do
    probe_options=()
    if [[ "$probe_kind" != force ]]; then probe_options+=(--energy-only); fi
    if [[ "$probe_kind" == profiled ]]; then
      probe_options+=(--host-trace-dir "/tmp/vibeqc-310-setup-$probe_domain-traces")
    fi
    /home/jzzeng/codes/vibeqc-issue-310/.venv/bin/python benchmarks/issue206_df_matrix.py --run --host-workloads \
      --setup-eigen-ablation --case "$probe_case" --batch "$probe_batch" \
      --library build/cuda/libvibeqc.so --memory-budget-bytes 1073741824 --repeats 5 \
      "${probe_options[@]}" --output-dir "/tmp/vibeqc-310-setup-$probe_domain-$probe_kind"
  done
done
