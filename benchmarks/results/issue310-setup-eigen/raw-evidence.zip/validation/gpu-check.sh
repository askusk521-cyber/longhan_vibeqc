#!/usr/bin/env bash
set -euo pipefail
cd /home/jzzeng/codes/vibeqc-issue-310-setup
[[ -n "$SLURM_JOB_ID" && -n "$CUDA_VISIBLE_DEVICES" ]]
[[ -z $(git status --porcelain) ]]
export PYTHONPATH=.:python
export OMP_NUM_THREADS=1
export OPENBLAS_NUM_THREADS=1
export VIBEQC_LIBRARY=$PWD/build/cuda/libvibeqc.so
export VIBEQC_RESOURCE_CUDA_TEST=1
export VIBEQC_TEST_FOCK_DEVICE=cuda
VIBEQC_ONE_ELECTRON_DERIVATIVES=generated ctest --test-dir build/cuda -R 'vibeqc_(df_eigensystem|density_fitting|cuda_fock_composition|cuda_fock_provider|native)_tests' --output-on-failure > /tmp/vibeqc-310-setup-gpu-native.log 2>&1
/home/jzzeng/codes/vibeqc-issue-310/.venv/bin/python -m pytest -q tests/python/test_df_setup_eigen_cuda.py tests/python/test_df_final_eigen_cuda.py tests/python/test_df_host_trace.py tests/python/test_hf_resources_cuda.py tests/python/test_fock.py tests/python/test_df_resources.py tests/python/test_df_occupied_cuda.py > /tmp/vibeqc-310-setup-gpu-python.log 2>&1
/group/software/cuda-12.9.1/bin/compute-sanitizer --tool memcheck --leak-check full --error-exitcode 99 build/cuda/vibeqc_df_eigensystem_tests > /tmp/vibeqc-310-setup-gpu-memcheck.log 2>&1
