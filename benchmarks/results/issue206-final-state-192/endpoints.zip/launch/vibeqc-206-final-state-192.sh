#!/usr/bin/env bash
set -euo pipefail
cd /home/jzzeng/codes/vibeqc-issue-310-setup
[[ -n "$SLURM_JOB_ID" && -n "$CUDA_VISIBLE_DEVICES" ]]
export PYTHONPATH=.:python
export OMP_NUM_THREADS=1
export OPENBLAS_NUM_THREADS=1
export VIBEQC_LIBRARY=/tmp/vibeqc-320-qualified/libvibeqc.so
export VIBEQC_RESOURCE_CUDA_TEST=1
printf 'Slurm job: %s\n' "$SLURM_JOB_ID"
/usr/bin/nvidia-smi --query-gpu=name,uuid,driver_version --format=csv
/home/jzzeng/codes/vibeqc-issue-310/.venv/bin/python - <<'PY'
from pathlib import Path
import json,os,subprocess,sys,hashlib,ctypes
from vibeqc.autotune import source_identity
root=Path('/tmp/vibeqc-206-final-state-192');root.mkdir(exist_ok=False)
lib=Path(os.environ['VIBEQC_LIBRARY']);handle=ctypes.CDLL(str(lib))
handle.vibeqc_get_source_identity.restype=ctypes.c_char_p
assert handle.vibeqc_get_source_identity().decode()==source_identity(Path.cwd())
identity={'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'source_identity':source_identity(Path.cwd()),'library_sha256':hashlib.sha256(lib.read_bytes()).hexdigest(),'slurm_job':os.environ['SLURM_JOB_ID'],'cuda_visible_devices':os.environ['CUDA_VISIBLE_DEVICES']}
(root/'identity.json').write_text(json.dumps(identity,indent=2)+'\n')
failed=[]
for phase in ('traced','clean'):
 for mode in ('final-state','combined-host'):
  for forces in (False,True):
   label=f'{phase}-{mode}-'+('forces' if forces else 'energy')
   out=root/label
   command=[sys.executable,'benchmarks/issue206_df_matrix.py','--run','--host-workloads',f'--{mode}-ablation','--case','water-octamer-s4-def2-svp-spherical','--batch','1','--repeats','5','--library',str(lib),'--output-dir',str(out)]
   if not forces: command+=['--energy-only']
   if phase=='traced': command+=['--host-trace-dir',str(root/(label+'-traces'))]
   print('START',label,flush=True)
   (root/(label+'-command.json')).write_text(json.dumps(command,indent=2)+'\n')
   with (root/(label+'.log')).open('w') as f:
    result=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT)
   print('END',label,'returncode',result.returncode,flush=True)
   if result.returncode: failed.append(label)
(root/'status.json').write_text(json.dumps({'failed':failed},indent=2)+'\n')
raise SystemExit(bool(failed))
PY
