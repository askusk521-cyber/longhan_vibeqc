#!/usr/bin/env bash
set -euo pipefail
cd /home/jzzeng/codes/vibeqc-issue-308-followup
[[ -n "$SLURM_JOB_ID" && -n "$CUDA_VISIBLE_DEVICES" ]]
export PYTHONPATH=python:. OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
export VIBEQC_LIBRARY=$PWD/build/cuda/libvibeqc.so
export VIBEQC_RESOURCE_CUDA_TEST=1
export VIBEQC_DF_VALUE_MAPPING=primitive
runner=/tmp/vibeqc-pr-review-env/bin/python
"$runner" -m pytest -q tests/python/test_df_retry_eigen_cuda.py tests/python/test_df_setup_eigen_cuda.py tests/python/test_df_final_state_cuda.py tests/python/test_df_occupied_cuda.py > .artifacts/issue308-stage/gpu-regressions.txt 2>&1
for ao in 96 192 384; do
  "$runner" -m benchmarks.issue308_stage_probe --input ".artifacts/issue308-stage/input-$ao" --output ".artifacts/issue308-stage/resident-$ao" --library "$VIBEQC_LIBRARY" --probe .artifacts/df-stage-probe --progress --timeout 180
  "$runner" -m benchmarks.issue308_stage_probe --input ".artifacts/issue308-stage/input-$ao" --output ".artifacts/issue308-stage/streamed-$ao" --library "$VIBEQC_LIBRARY" --probe .artifacts/df-stage-probe --progress --ao-pairs 8192 --auxiliary-tile 128 --timeout 180
 done
"$runner" -m benchmarks.issue308_stage_probe --input .artifacts/issue308-stage/input-768 --output .artifacts/issue308-stage/resident-768 --library "$VIBEQC_LIBRARY" --probe .artifacts/df-stage-probe --progress --timeout 240
"$runner" -m benchmarks.issue308_stage_probe --input .artifacts/issue308-stage/input-768 --output .artifacts/issue308-stage/streamed-768 --library "$VIBEQC_LIBRARY" --probe .artifacts/df-stage-probe --progress --ao-pairs 8192 --auxiliary-tile 128 --operation dense --timeout 120
