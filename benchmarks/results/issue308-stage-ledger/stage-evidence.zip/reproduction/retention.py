"""Publish reviewed phase measurements; retain failures and distinguish input work."""
from pathlib import Path
import hashlib,json,zipfile
root=Path(__file__).resolve().parent
out=Path('benchmarks/results/issue308-stage-ledger')
sha=lambda data:hashlib.sha256(data).hexdigest()
files={}; summaries=[]
names=['resident-96','streamed-96','streamed-96-valid','resident-192','streamed-192','resident-384','streamed-384','resident-768','streamed-768']
for name in names:
 p=root/name;r=json.loads((p/'result.json').read_text());assert r['status']!='running'
 for leaf in ['result.json','native.jsonl','cuda.jsonl','progress.jsonl','measured-source.patch']:
  if (p/leaf).exists():files[name+'/'+leaf]=(p/leaf).read_bytes()
 if (p/'stderr.txt').exists() and (p/'stderr.txt').stat().st_size:
  r['failure_detail']=(p/'stderr.txt').read_text()
 phase=r.get('progress',{}).get('phases',{})
 observations=r.get('progress',{}).get('observations',[])
 kshape={}
 for observation in observations:
  if observation['name']=='ri_k' and observation['key'] in ('planner_ao_pair_tile','planner_auxiliary_tile','executed_ao_rows','executed_auxiliary_tile'):
   kshape[observation['key']]=observation['value']
 completed_operations=[]
 if (p/'cuda.jsonl').exists():
  for line in (p/'cuda.jsonl').read_text().splitlines():
   trace=json.loads(line)
   if trace['execution']!='stream' or trace['operation'] not in ('ri_j','ri_k','ri_k_occupied'):continue
   logical=trace['counters'].get('raw_value_bytes',0)//8+trace['counters'].get('fused_source_auxiliary_evaluations',0)
   completed_operations.append({'operation':trace['operation'],'logical_source_evaluations':logical,'equivalent_raw_tensor_passes':logical/(trace['nbf']**2*trace['naux'])})
 gpu=[int(value.split(',')[1].strip()) for row in r['memory_samples'] for value in row['gpu_process_memory']]
 host=[int(value.split()[1])*1024 for row in r['memory_samples'] for value in row['host'] if value.startswith('VmHWM:')]
 summary={'run':name,'status':r['status'],'slurm_job':r['slurm_job'],'seconds':r['seconds'],'native_rows':r['native_rows'],'independent_errors':r['independent_checks'],'failure_detail':r.get('failure_detail'),'k_shape':kshape,'completed_jk_work':completed_operations,'phases':phase,'pending':r.get('progress',{}).get('pending',[]),'peak_sampled_process_gpu_mib':max(gpu) if gpu else None,'observed_process_host_high_water_bytes':max(host) if host else None,'source':r['source'],'native_source_identity':r['native_source_identity'],'cuda_runtime_version':r['cuda_runtime_version'],'driver':r['driver'],'diagnostic_environment':r['diagnostic_environment'],'input':r['input']}
 if (p/'arrays.bin').exists():summary['full_comparison_arrays']={'bytes':(p/'arrays.bin').stat().st_size,'sha256':sha((p/'arrays.bin').read_bytes()),'retention':'Transient native J/K outputs; independent maximum errors cover every component, and exact inputs/runner are retained for reproduction.'}
 summaries.append(summary)
for n in (96,192,384,768):files[f'input-{n}/input.json']=(root/f'input-{n}/input.json').read_bytes()
files['reproduction/run-bounded.sh']=(root/'run-bounded.sh').read_bytes()
files['reproduction/retention.py']=Path(__file__).read_bytes()
with zipfile.ZipFile(out/'stage-evidence.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,data in sorted(files.items()):z.writestr(name,data)
with zipfile.ZipFile(out/'stage-evidence.zip') as z:
 assert all(z.read(name)==data for name,data in files.items())
result={'schema':'vibeqc.issue308.stage-ledger.v1','scope':'Diagnostic stage and fixed-D measurements. No clean endpoint speedup or GPU4PySCF parity claim. Incomplete K probes do not validate full K output.','runs':summaries,'qualification':{'slurm_job':'9538','gpu_pytest':'57 passed in 111.49s','files':['tests/python/test_df_retry_eigen_cuda.py','tests/python/test_df_setup_eigen_cuda.py','tests/python/test_df_final_state_cuda.py','tests/python/test_df_occupied_cuda.py'],'log_sha256':sha((root/'gpu-regressions.txt').read_bytes()),'native_source_commit':'4d515cf800bf75606098c968ba59ac8c3726be5c'},'archive':{'path':'stage-evidence.zip','sha256':sha((out/'stage-evidence.zip').read_bytes()),'bytes':(out/'stage-evidence.zip').stat().st_size,'restoration':'Every member reread and compared byte-for-byte.'},'files':[{'path':name,'bytes':len(data),'sha256':sha(data)} for name,data in sorted(files.items())]}
(out/'stage-summary.json').write_text(json.dumps(result,indent=2)+'\n')
policy=Path('benchmarks/evidence-policy.json');m=json.loads(policy.read_text());m['exceptions'][str(out/'stage-evidence.zip')]={'owner':'issue308-stage-ledger','reason':'Exact accepted/rejected/timeout phase measurements, source/input identities and complete event journals from 9538/9539. The interrupted journal is the scientific evidence locating incomplete K work; no routine build/test logs or executable products.','sha256':result['archive']['sha256']};policy.write_text(json.dumps(m,indent=2,sort_keys=True)+'\n')
print(result['archive'])
