#!/usr/bin/env bash
set -euo pipefail
[[ -n "$SLURM_JOB_ID" && -n "$CUDA_VISIBLE_DEVICES" ]]
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 VIBEQC_DF_VALUE_MAPPING=primitive VIBEQC_PROBE_SAMPLES=3
root=/tmp/vibeqc-308-source-register
mkdir "$root"
printf 'Slurm job: %s\n' "$SLURM_JOB_ID"
sha256sum /tmp/vibeqc-308-source-reg128.so /tmp/vibeqc-308-source-reg128.cu /tmp/vibeqc-308-source-register-probe /home/jzzeng/codes/vibeqc-issue-310-setup/build/cuda/libvibeqc.so > "$root/hashes.txt"
LD_DEBUG=bindings LD_PRELOAD=/tmp/vibeqc-308-source-reg128.so /tmp/vibeqc-308-source-register-probe /tmp/vibeqc-308-source-scaling/water-32.txt "$root/binding-probe" 24 24 > "$root/binding-probe.json" 2> "$root/bindings.log"
for sample in 0 1 2 3; do
  if [[ "$sample" == 0 || "$sample" == 3 ]]; then
    label=baseline
    timeout 90 /tmp/vibeqc-308-source-register-probe /tmp/vibeqc-308-source-scaling/water-32.txt "$root/$sample-$label" 768 768 > "$root/$sample-$label.json"
  else
    label=reg128
    LD_PRELOAD=/tmp/vibeqc-308-source-reg128.so timeout 90 /tmp/vibeqc-308-source-register-probe /tmp/vibeqc-308-source-scaling/water-32.txt "$root/$sample-$label" 768 768 > "$root/$sample-$label.json"
  fi
done
