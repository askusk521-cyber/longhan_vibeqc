#!/usr/bin/env bash
set -euo pipefail
cd /home/jzzeng/codes/vibeqc-issue-308-source-metadata
[[ -n "$SLURM_JOB_ID" && -n "$CUDA_VISIBLE_DEVICES" ]]
export PYTHONPATH=.:python OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
export VIBEQC_LIBRARY=$PWD/build/cuda/libvibeqc.so
export LD_LIBRARY_PATH=$PWD/build/cuda:${LD_LIBRARY_PATH:-}
export VIBEQC_RESOURCE_CUDA_TEST=1 VIBEQC_TEST_FOCK_DEVICE=cuda
export VIBEQC_DF_VALUE_MAPPING=primitive
printf 'Slurm job: %s\n' "$SLURM_JOB_ID"
/tmp/vibeqc-pr-review-env/bin/python - <<'PY'
from pathlib import Path
import ctypes,hashlib,json,os,subprocess
from vibeqc.autotune import source_identity
lib=Path(os.environ['VIBEQC_LIBRARY']);handle=ctypes.CDLL(str(lib))
handle.vibeqc_get_source_identity.restype=ctypes.c_char_p
native=handle.vibeqc_get_source_identity().decode();assert native==source_identity(Path.cwd())
linked=subprocess.check_output(['ldd','/tmp/vibeqc-308-source-scaling-probe'],text=True)
assert str(lib.parent/'libvibeqc.so.0') in linked
Path('/tmp/vibeqc-308-source-metadata-native-identity.json').write_text(json.dumps({'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'source_identity':native,'library_sha256':hashlib.sha256(lib.read_bytes()).hexdigest(),'slurm_job':os.environ['SLURM_JOB_ID'],'cuda_visible_devices':os.environ['CUDA_VISIBLE_DEVICES'],'linked_probe':linked},indent=2)+'\n')
PY
/tmp/vibeqc-308-source-scaling-probe /tmp/vibeqc-308-source-scaling/water-32.txt /tmp/vibeqc-308-source-metadata-96-atoms 24 24 > /tmp/vibeqc-308-source-metadata-96-atoms.json
/tmp/vibeqc-pr-review-env/bin/python - <<'PY'
from pathlib import Path
import json,numpy as np
baseline=json.loads(Path('/tmp/vibeqc-308-source-scaling/baseline-primitive-32.json').read_text())
candidate=json.loads(Path('/tmp/vibeqc-308-source-metadata-96-atoms.json').read_text())
assert candidate['source_device_bytes']==baseline['source_device_bytes']
assert candidate['source_host_peak_bytes'] < baseline['source_host_peak_bytes'] / 10
assert np.array_equal(np.fromfile('/tmp/vibeqc-308-source-scaling/baseline-primitive-32-raw.bin',dtype=np.float64),np.fromfile('/tmp/vibeqc-308-source-metadata-96-atoms-raw.bin',dtype=np.float64))
Path('/tmp/vibeqc-308-source-metadata-comparison.json').write_text(json.dumps({'baseline_host_peak_bytes':baseline['source_host_peak_bytes'],'candidate_host_peak_bytes':candidate['source_host_peak_bytes'],'device_bytes_unchanged':candidate['source_device_bytes'],'raw_fixed_tile_bit_identical':True,'scope':'96-atom source construction and a fixed raw tile only; no SCF or full-force endpoint'},indent=2)+'\n')
PY
VIBEQC_ONE_ELECTRON_DERIVATIVES=generated ctest --test-dir build/cuda -R 'vibeqc_(df_final_snapshot|df_eigensystem|density_fitting|cuda_fock_provider|native)_tests' --output-on-failure > /tmp/vibeqc-308-source-metadata-gpu-native.log 2>&1
/tmp/vibeqc-pr-review-env/bin/python -m pytest -q tests/python/test_df_setup_eigen_cuda.py tests/python/test_df_final_state_cuda.py tests/python/test_hf_resources_cuda.py tests/python/test_df_resources.py > /tmp/vibeqc-308-source-metadata-gpu-python.log 2>&1
/group/software/cuda-12.9.1/bin/compute-sanitizer --tool memcheck --leak-check full --error-exitcode 99 /tmp/vibeqc-308-source-scaling-probe /tmp/vibeqc-308-source-scaling/water-32.txt /tmp/vibeqc-308-source-metadata-memcheck 24 24 > /tmp/vibeqc-308-source-metadata-memcheck.log 2>&1
