#!/usr/bin/env bash
set -euo pipefail
[[ -n "$SLURM_JOB_ID" && -n "$CUDA_VISIBLE_DEVICES" ]]
cd /home/jzzeng/codes/vibeqc-issue-310-setup
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
for mapping in primitive auxiliary component; do
  for waters in 1 8 32; do
    VIBEQC_DF_VALUE_MAPPING=$mapping timeout 90 /tmp/vibeqc-308-source-scaling-probe /tmp/vibeqc-308-source-scaling/water-$waters.txt /tmp/vibeqc-308-source-scaling/baseline-$mapping-$waters 24 24 > /tmp/vibeqc-308-source-scaling/baseline-$mapping-$waters.json
  done
done
