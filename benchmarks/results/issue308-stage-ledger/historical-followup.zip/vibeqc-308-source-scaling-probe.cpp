/** Manual Slurm-only probe of the exact native DF source and J/K integration.
 *
 * Text inputs describe unnormalized physical basis shells; independent Python
 * libcint references use the same input. Binary outputs are raw FP64 M/A/J/K
 * tensors, never values reconstructed from the generated recurrence itself.
 */
#include <cuda_runtime_api.h>

#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <memory>
#include <stdexcept>
#include <string>
#include <vector>

#include "integrals/s_integrals.hpp"
#include "molecule/basis.hpp"
#include "scf/cuda_density_fitting.hpp"
#include "scf/cuda_density_fitting_integrals.hpp"

namespace {
using Clock = std::chrono::steady_clock;
using vibeqc::core::System;
using namespace vibeqc::scf;

void check(cudaError_t status) {
  if (status != cudaSuccess) throw std::runtime_error(cudaGetErrorString(status));
}
void require(bool ok, const std::string& message) {
  if (!ok) throw std::runtime_error(message);
}
double milliseconds(Clock::time_point start) {
  return std::chrono::duration<double, std::milli>(Clock::now() - start).count();
}
void write_values(const std::string& path, const std::vector<double>& values) {
  std::ofstream stream(path, std::ios::binary);
  stream.write(reinterpret_cast<const char*>(values.data()), values.size() * sizeof(double));
  require(static_cast<bool>(stream), "cannot write " + path);
}
void read_shells(std::istream& input, System& system, std::size_t count) {
  require(count > 0 && count <= 2048, "invalid fixture shell count");
  for (std::size_t shell = 0; shell < count; ++shell) {
    vibeqc::core::Shell value;
    std::size_t primitives;
    input >> value.atom_index >> value.angular_momentum >> primitives;
    require(primitives > 0 && primitives <= 64, "invalid fixture contraction length");
    for (std::size_t primitive = 0; primitive < primitives; ++primitive) {
      double exponent, coefficient;
      input >> exponent >> coefficient;
      value.primitives.push_back({exponent, coefficient});
    }
    system.shells.push_back(value);
  }
  std::string detail;
  require(static_cast<bool>(input), "truncated fixture input");
  require(vibeqc::molecule::validate_and_normalize(system, detail) == VIBEQC_STATUS_SUCCESS,
          detail);
}
}  // namespace

int main(int argc, char** argv) {
  try {
    require(argc == 5 || (argc == 6 && std::string(argv[5]) == "--derivatives"),
            "usage: probe input output-prefix pair-tile auxiliary-tile [--derivatives]");
    
    require(std::getenv("SLURM_JOB_ID") != nullptr, "native DF probe requires a Slurm allocation");
    const std::string prefix = argv[2];
    const std::size_t pair_tile = std::stoul(argv[3]), auxiliary_tile = std::stoul(argv[4]);
    require(pair_tile > 0 && auxiliary_tile > 0, "positive tile dimensions required");
    std::ifstream input(argv[1]);
    std::size_t count;
    unsigned representation;
    input >> count >> representation;
    require(count > 0 && count <= 8 && representation <= 1, "invalid fixture batch");
    std::vector<System> orbital(count), auxiliary(count);
    for (std::size_t system = 0; system < count; ++system) {
      std::size_t atoms, orbital_shells, auxiliary_shells;
      input >> atoms >> orbital_shells >> auxiliary_shells;
      require(atoms > 0 && atoms <= 100, "invalid fixture geometry");
      for (std::size_t atom = 0; atom < atoms; ++atom) {
        vibeqc::core::Atom value;
        input >> value.atomic_number >> value.position[0] >> value.position[1] >> value.position[2];
        orbital[system].atoms.push_back(value);
      }
      orbital[system].basis_representation =
          representation == 0 ? VIBEQC_BASIS_CARTESIAN : VIBEQC_BASIS_SPHERICAL;
      auxiliary[system] = orbital[system];
      read_shells(input, orbital[system], orbital_shells);
      read_shells(input, auxiliary[system], auxiliary_shells);
    }
    std::string detail;
    CudaDensityFittingIntegralSource* raw_source = nullptr;
    std::vector<double> metric;
    std::size_t nbf = 0, naux = 0;
    auto start = Clock::now();
    require(create_cuda_density_fitting_integral_source(0, orbital, auxiliary, &raw_source, metric,
                                                        nbf, naux, detail) == VIBEQC_STATUS_SUCCESS,
            detail);
    const double setup_ms = milliseconds(start);
    auto source = std::unique_ptr<CudaDensityFittingIntegralSource,
                                  decltype(&destroy_cuda_density_fitting_integral_source)>(
        raw_source, &destroy_cuda_density_fitting_integral_source);
    const auto placement = cuda_density_fitting_integral_source_diagnostic(source.get());
    const auto source_device_bytes =
        cuda_density_fitting_integral_source_device_bytes(source.get());
    const auto source_host_peak_bytes =
        cuda_density_fitting_integral_source_host_peak_bytes(source.get());
    const std::size_t pc = std::min(pair_tile, nbf), ac = std::min(auxiliary_tile, naux);
    cudaStream_t stream{};
    double* device{};
    check(cudaStreamCreateWithFlags(&stream, cudaStreamNonBlocking));
    check(cudaMalloc(reinterpret_cast<void**>(&device), pc * ac * sizeof(double)));
    std::vector<double> result(pc * ac), times;
    for (unsigned sample = 0; sample < 11; ++sample) {
      start = Clock::now();
      require(generate_cuda_density_fitting_raw_tile(source.get(), 0, 0, pc, 0, ac, -1, stream, device, detail) == VIBEQC_STATUS_SUCCESS, detail);
      check(cudaStreamSynchronize(stream));
      if (sample) times.push_back(milliseconds(start));
    }
    check(cudaMemcpy(result.data(), device, result.size() * sizeof(double), cudaMemcpyDeviceToHost));
    write_values(prefix + "-raw.bin", result);
    check(cudaFree(device));
    check(cudaStreamDestroy(stream));
    std::cout << std::setprecision(12) << "{\"nbf\":" << nbf << ",\"naux\":" << naux
              << ",\"pair_count\":" << pc << ",\"auxiliary_count\":" << ac
              << ",\"source_setup_ms\":" << setup_ms
              << ",\"source_device_bytes\":" << source_device_bytes
              << ",\"source_host_peak_bytes\":" << source_host_peak_bytes
              << ",\"mapping\":" << std::quoted(placement.value_mapping)
              << ",\"slurm_job\":" << std::quoted(std::getenv("SLURM_JOB_ID"))
              << ",\"raw_tile_ms\":[";
    for (std::size_t i = 0; i < times.size(); ++i) std::cout << (i ? "," : "") << times[i];
    std::cout << "]}\n";
  } catch (const std::exception& error) {
    std::cerr << error.what() << '\n';
    return 1;
  }
}
