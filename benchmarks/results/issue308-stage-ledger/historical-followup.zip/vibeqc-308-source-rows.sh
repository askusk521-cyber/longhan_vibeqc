#!/usr/bin/env bash
set -euo pipefail
[[ -n "$SLURM_JOB_ID" && -n "$CUDA_VISIBLE_DEVICES" ]]
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 VIBEQC_DF_VALUE_MAPPING=primitive VIBEQC_PROBE_SAMPLES=2
root=/tmp/vibeqc-308-source-rows-v2
mkdir "$root"
printf 'Slurm job: %s\n' "$SLURM_JOB_ID"
for row in 0 3 9 11 14 16; do
  VIBEQC_PROBE_ROW=$row timeout 90 /tmp/vibeqc-308-source-row-probe /tmp/vibeqc-308-source-scaling/water-32.txt "$root/row-$row" 768 768 > "$root/row-$row.json"
done
