#!/usr/bin/env bash
set -euo pipefail
[[ -n "$SLURM_JOB_ID" && -n "$CUDA_VISIBLE_DEVICES" ]]
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 VIBEQC_DF_VALUE_MAPPING=primitive
root=/tmp/vibeqc-308-source-full
mkdir "$root"
printf 'Slurm job: %s\n' "$SLURM_JOB_ID"
set +e
timeout 240 /tmp/vibeqc-308-source-full-probe /tmp/vibeqc-308-source-scaling/water-32.txt "$root/full" 589824 768 > "$root/result.json" 2> "$root/native.log"
status=$?
printf '{"slurm_job":%s,"exit_status":%s,"scope":"diagnostic complete raw tensor generation only; retained values cover the first 24 AO pairs"}\n' "$SLURM_JOB_ID" "$status" > "$root/disposition.json"
exit "$status"
