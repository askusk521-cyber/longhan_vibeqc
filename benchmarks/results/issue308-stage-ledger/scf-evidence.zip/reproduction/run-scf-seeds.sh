#!/usr/bin/env bash
set -euo pipefail
cd /home/jzzeng/codes/vibeqc-issue-308-followup
[[ -n "$SLURM_JOB_ID" && -n "$CUDA_VISIBLE_DEVICES" ]]
export PYTHONPATH=python:. OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
export VIBEQC_DF_VALUE_MAPPING=primitive
printf 'Slurm job: %s\n' "$SLURM_JOB_ID"
for mode in seeded cold; do
  out="$PWD/.artifacts/issue308-stage/scf-$mode-768"
  mkdir "$out"
  export VIBEQC_DF_PROGRESS_TRACE="$out/progress.jsonl"
  export VIBEQC_DF_TRACE="$out/cuda.jsonl"
  export VIBEQC_DF_HOST_TRACE="$out/host.jsonl"
  set +e
  /usr/bin/time -v timeout 330 "$PWD/.artifacts/scf-seed-probe" "$PWD/.artifacts/issue308-stage/input-768/input.txt" 1 0 0 "$out/arrays.bin" "$mode" 100 > "$out/native.jsonl" 2> "$out/stderr.txt"
  status=$?
  set -e
  printf '{"slurm_job":"%s","exit_status":%s,"scope":"native production RHF energy with physical export; fixed 28 GiB DF subbudget, not a global-resource acceptance"}\n' "$SLURM_JOB_ID" "$status" > "$out/disposition.json"
done
