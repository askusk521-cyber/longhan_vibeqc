"""Retain reviewed native energy diagnostics, exact journals and bounded state samples."""
from pathlib import Path
import hashlib, io, json, re, zipfile
import numpy as np

root = Path(__file__).resolve().parent
out = Path('benchmarks/results/issue308-stage-ledger')
sha = lambda data: hashlib.sha256(data).hexdigest()
files = {}
runs = []
identity = json.loads((root/'resident-768/result.json').read_text())
frozen = Path('.artifacts/issue308-frozen-4d515cf/libvibeqc.so.0.1.0')
assert sha(frozen.read_bytes()) == identity['source']['native_library_sha256']
for mode in ['seeded', 'cold']:
    name = f'scf-{mode}-768'
    p = root/name
    validation = json.loads((p/'state-validation.json').read_text())
    progress = json.loads((p/'progress-summary.json').read_text())
    disposition = json.loads((p/'disposition.json').read_text())
    assert disposition['exit_status'] == 0 and progress['complete_journal']
    native = [json.loads(s) for s in (p/'native.jsonl').read_text().splitlines()]
    loaded = next(r for r in native if r['operation'] == 'identity')
    assert loaded['source_identity'] == identity['native_source_identity']
    assert Path(loaded['library']).resolve() == Path(identity['source']['native_library']).resolve()
    for leaf in ['state-validation.json', 'progress-summary.json', 'disposition.json', 'native.jsonl', 'progress.jsonl', 'cuda.jsonl', 'host.jsonl']:
        files[name+'/'+leaf] = (p/leaf).read_bytes()
    # Full transient exports stay in the durable workspace for follow-up force
    # work. Retain a bounded exact sample and every orbital energy for review;
    # recorded full-array checks cover all components, not just these rows.
    values = np.fromfile(p/'arrays.bin', dtype='<f8')
    n = 768
    assert values.size == 5*n*n+n
    assert sha((p/'arrays.bin').read_bytes()) == validation['array_sha256']
    sample = io.BytesIO()
    matrices = values[:5*n*n].reshape(5,n,n)
    np.savez(sample, **{key: matrix[:24].copy() for key,matrix in zip(['D','S','H','F','C'],matrices)}, epsilon=values[5*n*n:])
    files[name+'/first-24-rows.npz'] = sample.getvalue()
    observations = progress['observations']
    phases = progress['phases']
    iterations = [o['value'] for o in observations if o['key']=='device_iterations']
    launches = [o for o in observations if o['key']=='host_graph_replay']
    host_memory = int(re.search(r'Maximum resident set size \(kbytes\): (\d+)', (p/'stderr.txt').read_text())[1])*1024
    runs.append({
        'mode': mode, 'loaded_identity':loaded, 'disposition': disposition, 'endpoint': validation['endpoint'],
        'errors': validation['errors'], 'phases': phases,
        'compact_device_iterations': max(iterations),
        'retry_iterations': phases.get('host:diis_retry_iteration',{}).get('calls',0),
        'final_physical_fock_builds': phases['host:final_state_fock_build']['calls'],
        'graph_host_replays': sum(o['value'] for o in launches),
        'graph_construction_attempts':sum(o['value'] for o in observations if o['key']=='graph_construction_attempt'),
        'reference_eigensolves': validation['host_components']['eigensolves_by_reason'],
        'host_dispatched_device_eigensolves': validation['host_components']['device_eigensolves_by_reason'],
        'host_peak_rss_bytes': host_memory, 'gpu_peak_bytes': None,
        'memory_scope': 'SCF probe retained process host high water only. Fixed-D GPU sampled peak is a separate run.',
        'array_sha256': validation['array_sha256'],
        'array_retention': {'full': str((p/'arrays.bin').resolve()),'sample':'first 24 rows of D/S/H/F/C plus all epsilon; float64 little endian'},
    })
for leaf in ['scf-seed-probe.cpp','run-scf-seeds.sh','validate_scf_state.py']:
    files['reproduction/'+leaf] = (root/leaf).read_bytes()
files['reproduction/retain_scf_ledger.py'] = Path(__file__).read_bytes()
files['reproduction/CMakeCache.txt'] = (root/'resident-768/CMakeCache.txt').read_bytes()
with zipfile.ZipFile(out/'scf-evidence.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for name,data in sorted(files.items()): archive.writestr(name,data)
with zipfile.ZipFile(out/'scf-evidence.zip') as archive:
    assert all(archive.read(name)==data for name,data in files.items())
result = {
    'schema':'vibeqc.issue308.scf-ledger.v1',
    'scope':'Diagnostic native RHF energy with physical export and a 28 GiB DF subbudget, not public global-resource acceptance or clean performance. Seeded timing is not cold timing. Native force W and complete forces remain untested; W checks derive W from C/epsilon.',
    'source': identity['source'], 'native_source_identity': identity['native_source_identity'],
    'binary_verification':'Native output records the loaded absolute path and source identity. The measured fixed-D library with matching path/identity was frozen and hash-verified before rebuilding. SCF launcher did not record a separate launch-time binary hash.',
    'frozen_library':str(frozen.resolve()), 'probe_sha256':sha(Path('.artifacts/scf-seed-probe').read_bytes()),
    'build':'Release; CUDA 12.9.1; sm_120; fast compile OFF; stable-shards; complete CMakeCache retained.',
    'hardware_from_fixed_density_job':{k:identity[k] for k in ['driver','cuda_runtime_version','cuda_visible_devices']},
    'diagnostic_environment':{'VIBEQC_DF_VALUE_MAPPING':'primitive','VIBEQC_DF_PROGRESS_TRACE':'per-mode/progress.jsonl','VIBEQC_DF_TRACE':'per-mode/cuda.jsonl','VIBEQC_DF_HOST_TRACE':'per-mode/host.jsonl'},
    'input':identity['input'], 'runs':runs,
    'archive':{'path':'scf-evidence.zip','sha256':sha((out/'scf-evidence.zip').read_bytes()),'bytes':(out/'scf-evidence.zip').stat().st_size,'restoration':'Every selected member reread and compared byte-for-byte.'},
    'files':[{'path':name,'bytes':len(data),'sha256':sha(data)} for name,data in sorted(files.items())],
}
(out/'scf-summary.json').write_text(json.dumps(result,indent=2)+'\n')
policy=Path('benchmarks/evidence-policy.json');m=json.loads(policy.read_text())
m['exceptions'][str(out/'scf-evidence.zip')]={
    'owner':'issue308-stage-ledger',
    'reason':'Exact completed cold/seeded phase journals, full-array physical validation errors, bounded first-24-row state samples, all orbital energies, and reproduction input/code from job 9540. Full transient exports remain outside Git; every retained member byte-restored. No routine logs or binaries.',
    'sha256':result['archive']['sha256'],
}
policy.write_text(json.dumps(m,indent=2,sort_keys=True)+'\n')
print(result['archive'])
