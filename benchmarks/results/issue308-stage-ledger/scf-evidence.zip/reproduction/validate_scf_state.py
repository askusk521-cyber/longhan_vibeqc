"""Validate completed native physical exports against independent fixed-D input."""
from pathlib import Path
import hashlib,json,sys
import numpy as np
from pyscf import gto
from benchmarks._cases import benchmark_cases
from benchmarks.df_component_ledger import aggregate_host,read_host_trace
root=Path(__file__).resolve().parent
fixture=root/'input-768'
metadata=json.loads((fixture/'input.json').read_text())
case=benchmark_cases()[metadata['case']]
mol=gto.M(atom=case.atoms,basis=case.pyscf_basis,unit='Bohr',cart=False,verbose=0)
n=mol.nao; rank=mol.nelectron//2
for mode in sys.argv[1:] or ['seeded','cold']:
 p=root/f'scf-{mode}-768'
 disposition=json.loads((p/'disposition.json').read_text())
 assert disposition['exit_status']==0,disposition
 rows=[json.loads(s) for s in (p/'native.jsonl').read_text().splitlines()]
 endpoint=next(r for r in rows if r['operation']==mode)
 assert endpoint['converged']
 x=np.fromfile(p/'arrays.bin');assert x.size==5*n*n+n
 D,S,H,F,C=x[:5*n*n].reshape(5,n,n);eps=x[5*n*n:]
 with np.load(fixture/'reference.npz') as ref:
  errors={'density_vs_pyscf_max':float(np.max(np.abs(D-ref['density']))),'overlap_vs_pyscf_max':float(np.max(np.abs(S-ref['overlap']))),'physical_fock_vs_pyscf_jk_max':float(np.max(np.abs(F-(H+ref['j']-0.5*ref['k']))))}
 errors.update({'eigen_residual_max':float(np.max(np.abs(F@C-(S@C)*eps))),'orthogonality_max':float(np.max(np.abs(C.T@S@C-np.eye(n)))),'electron_trace_error':float(abs(np.einsum('ij,ji',D,S)-mol.nelectron)),'idempotency_max':float(np.max(np.abs(D@S@D-2*D))),'commutator_max':float(np.max(np.abs(F@D@S-S@D@F))),'canonical_density_max':float(np.max(np.abs(D-2*C[:,:rank]@C[:,:rank].T)))})
 W=2*(C[:,:rank]*eps[:rank])@C[:,:rank].T
 errors['derived_energy_weighted_equation_max']=float(np.max(np.abs(F@D-S@W)))
 errors['energy_vs_pyscf']=abs(endpoint['energy']-metadata['energy'])
 errors['energy_reconstruction']=abs(endpoint['energy']-(np.einsum('ij,ij',D,H+F)*.5+mol.energy_nuc()))
 assert all(np.all(np.isfinite(v)) for v in (D,S,H,F,C,eps,W))
 assert max(errors.values())<1e-8,errors
 assert errors['energy_vs_pyscf']<1e-9,errors
 host=aggregate_host(read_host_trace(p/'host.jsonl'))
 assert not host['eigensolves_by_reason']
 result={'schema':'vibeqc.issue308.seeded-state-validation.v1','mode':mode,'scope':'Native RHF energy with physical export. W is independently derived from exported C/epsilon; native force W and complete forces have not been checked here. Seeded timing is not cold-start timing.','errors':errors,'host_components':host,'array_sha256':hashlib.sha256((p/'arrays.bin').read_bytes()).hexdigest(),'input':metadata,'endpoint':endpoint}
 (p/'state-validation.json').write_text(json.dumps(result,indent=2)+'\n')
 print(mode,errors)
