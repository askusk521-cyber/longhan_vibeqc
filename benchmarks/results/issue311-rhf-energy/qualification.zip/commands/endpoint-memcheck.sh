#!/usr/bin/env bash
set -euo pipefail
cd /home/jzzeng/codes/vibeqc-issue-310-setup
[[ -n "$SLURM_JOB_ID" && -n "$CUDA_VISIBLE_DEVICES" ]]
printf 'Slurm job: %s\n' "$SLURM_JOB_ID"
export PYTHONPATH=.:python
export OMP_NUM_THREADS=1
export OPENBLAS_NUM_THREADS=1
export VIBEQC_LIBRARY=$PWD/build/cuda/libvibeqc.so
export VIBEQC_RESOURCE_CUDA_TEST=1
/group/software/cuda-12.9.1/bin/compute-sanitizer --tool memcheck --leak-check full --error-exitcode 99 /home/jzzeng/codes/vibeqc-issue-310/.venv/bin/python -m pytest -q 'tests/python/test_df_final_state_cuda.py::test_energy_selection_rebuild_and_force_transitions[0-1-cartesian]' > /tmp/vibeqc-311-energy-endpoint-memcheck.log 2>&1
