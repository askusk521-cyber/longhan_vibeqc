#!/usr/bin/env bash
set -euo pipefail
cd /home/jzzeng/codes/vibeqc-issue-310-iterative
[[ -n "$SLURM_JOB_ID" && -n "$CUDA_VISIBLE_DEVICES" ]]
export PYTHONPATH=.:python
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
export VIBEQC_LIBRARY=$PWD/build/cuda/libvibeqc.so
export VIBEQC_RESOURCE_CUDA_TEST=1 VIBEQC_TEST_FOCK_DEVICE=cuda
printf 'Slurm job: %s\n' "$SLURM_JOB_ID"
/tmp/vibeqc-pr-review-env/bin/python - <<'PY'
from pathlib import Path
import ctypes,hashlib,json,os,subprocess
from vibeqc.autotune import source_identity
lib=Path(os.environ['VIBEQC_LIBRARY']); handle=ctypes.CDLL(str(lib))
handle.vibeqc_get_source_identity.restype=ctypes.c_char_p
native=handle.vibeqc_get_source_identity().decode()
assert native==source_identity(Path.cwd())
Path('/tmp/vibeqc-310-iterative-native-identity.json').write_text(json.dumps({'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'source_identity':native,'library_sha256':hashlib.sha256(lib.read_bytes()).hexdigest(),'slurm_job':os.environ['SLURM_JOB_ID'],'cuda_visible_devices':os.environ['CUDA_VISIBLE_DEVICES'],'source_dirty':True},indent=2)+'\n')
PY
/tmp/vibeqc-pr-review-env/bin/python -m pytest -q tests/python/test_df_retry_eigen_cuda.py --basetemp=/tmp/vibeqc-310-iterative-traces > /tmp/vibeqc-310-iterative-gpu-retry.log 2>&1
VIBEQC_ONE_ELECTRON_DERIVATIVES=generated ctest --test-dir build/cuda -R 'vibeqc_(df_final_snapshot|df_eigensystem|density_fitting|cuda_fock_provider|native)_tests' --output-on-failure > /tmp/vibeqc-310-iterative-gpu-native.log 2>&1
/tmp/vibeqc-pr-review-env/bin/python -m pytest -q tests/python/test_df_setup_eigen_cuda.py tests/python/test_df_final_state_cuda.py tests/python/test_hf_resources_cuda.py > /tmp/vibeqc-310-iterative-gpu-python.log 2>&1
/group/software/cuda-12.9.1/bin/compute-sanitizer --tool memcheck --leak-check full --error-exitcode 99 /tmp/vibeqc-pr-review-env/bin/python -m pytest -q tests/python/test_df_retry_eigen_cuda.py -k 'batch-four and spherical' --basetemp=/tmp/vibeqc-310-iterative-memcheck-traces > /tmp/vibeqc-310-iterative-memcheck.log 2>&1
