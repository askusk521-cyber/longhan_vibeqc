#!/usr/bin/env bash
set -euo pipefail
cd /home/jzzeng/codes/vibeqc-issue-310-independent
[[ -n "$SLURM_JOB_ID" && -n "$CUDA_VISIBLE_DEVICES" ]]
export PYTHONPATH=.:python
export OMP_NUM_THREADS=1
export OPENBLAS_NUM_THREADS=1
export VIBEQC_LIBRARY=$PWD/build/cuda/libvibeqc.so
export VIBEQC_RESOURCE_CUDA_TEST=1
export VIBEQC_TEST_FOCK_DEVICE=cuda
printf 'Slurm job: %s\n' "$SLURM_JOB_ID"
/usr/bin/nvidia-smi --query-gpu=name,uuid,driver_version --format=csv
/tmp/vibeqc-pr-review-env/bin/python - <<'PY'
from pathlib import Path
import ctypes,hashlib,json,os,subprocess,sys
from vibeqc.autotune import source_identity
lib=Path(os.environ['VIBEQC_LIBRARY']);handle=ctypes.CDLL(str(lib));handle.vibeqc_get_source_identity.restype=ctypes.c_char_p
native=handle.vibeqc_get_source_identity().decode();assert native==source_identity(Path.cwd())
payload={'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'source_identity':native,'library_sha256':hashlib.sha256(lib.read_bytes()).hexdigest(),'slurm_job':os.environ['SLURM_JOB_ID'],'cuda_visible_devices':os.environ['CUDA_VISIBLE_DEVICES'],'python':sys.version}
Path('/tmp/vibeqc-310-independent-tight-native-identity.json').write_text(json.dumps(payload,indent=2)+'\n')
PY
/tmp/vibeqc-pr-review-env/bin/python -m pytest -q tests/python/test_fock_eigen_cuda.py -k 'unrestricted and (exact-density_fitted or density_fitted-exact)' --basetemp=/tmp/vibeqc-310-independent-tight-eigen-traces > /tmp/vibeqc-310-independent-tight-gpu-selection.log 2>&1
printf 'Independent molecular and provider checks complete\n'
VIBEQC_DF_HOST_TRACE=/tmp/vibeqc-310-independent-tight-composition.host.jsonl build/cuda/vibeqc_cuda_fock_composition_tests > /tmp/vibeqc-310-independent-tight-gpu-composition.log 2>&1
printf 'Independent composition and reference export checks complete\n'
VIBEQC_ONE_ELECTRON_DERIVATIVES=generated ctest --test-dir build/cuda -R 'vibeqc_(df_final_snapshot|df_eigensystem|density_fitting|cuda_fock_provider|native)_tests' --output-on-failure > /tmp/vibeqc-310-independent-tight-gpu-native.log 2>&1
/tmp/vibeqc-pr-review-env/bin/python -m pytest -q tests/python/test_fock.py tests/python/test_df_host_trace.py tests/python/test_df_setup_eigen_cuda.py tests/python/test_df_final_state_cuda.py tests/python/test_hf_resources_cuda.py tests/python/test_df_resources.py > /tmp/vibeqc-310-independent-tight-gpu-python.log 2>&1
printf 'GPU regression checks complete\n'
/group/software/cuda-12.9.1/bin/compute-sanitizer --tool memcheck --leak-check full --error-exitcode 99 /tmp/vibeqc-pr-review-env/bin/python -m pytest -q tests/python/test_fock_eigen_cuda.py -k 'empty_beta or (density_fitted-density_fitted and spherical and restricted)' --basetemp=/tmp/vibeqc-310-independent-tight-memcheck-traces > /tmp/vibeqc-310-independent-tight-memcheck.log 2>&1
printf 'Memcheck complete\n'
