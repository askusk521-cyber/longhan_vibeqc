"""Independent complete DF force oracle with reusable wavefunction checkpoint."""
from pathlib import Path
import hashlib,json,time,traceback
import numpy as np
import pyscf
from pyscf import gto,scf,lib
from benchmarks._cases import benchmark_cases
lib.num_threads(2)
case=benchmark_cases()['water-32mer-4s4-def2-svp-spherical']
root=Path('/tmp/vibeqc-308-96-atoms-pyscf-forces');root.mkdir(exist_ok=False)
r={'schema':'vibeqc.issue308.independent-forces.v1','status':'running','atoms':96,'ao_count':768,'basis':'def2-svp','auxiliary_basis':'def2-svp','method':'RHF','engine':'PySCF','engine_version':pyscf.__version__,'numpy_version':np.__version__,'cpu_threads':2,'energy_tolerance':1e-12,'gradient_tolerance':1e-10,'auxbasis_response':True,'iterations':[],'scope':'independent physical reference only; CPU wall time is not a matched GPU performance measurement'}
def save():(root/'result.json').write_text(json.dumps(r,indent=2)+'\n')
save();started=time.perf_counter()
try:
 mol=gto.M(atom=case.atoms,basis='def2-svp',unit='Bohr',cart=False,verbose=4,output=str(root/'pyscf.log'),max_memory=8000)
 mf=scf.RHF(mol).density_fit(auxbasis='def2-svp')
 mf.conv_tol=1e-12;mf.conv_tol_grad=1e-10;mf.max_cycle=100;mf.max_memory=8000
 mf.chkfile=str(root/'scf.chk')
 def callback(env):
  r['iterations'].append({'cycle':int(env['cycle']),'energy':float(env['e_tot']),'gradient_norm':float(env['norm_gorb']),'density_change':float(env['norm_ddm'])});save()
 mf.callback=callback
 r['energy']=float(mf.kernel());r['converged']=bool(mf.converged);save()
 assert mf.converged
 np.save(root/'density.npy',mf.make_rdm1())
 np.save(root/'overlap.npy',mf.get_ovlp())
 grad=mf.nuc_grad_method();grad.auxbasis_response=True
 forces=-grad.kernel();np.save(root/'forces.npy',forces)
 r['forces']=forces.tolist();r['maximum_net_force']=float(np.max(np.abs(forces.sum(axis=0))))
 r['status']='passed'
except Exception as error:
 r['status']='failed';r['error']=repr(error);r['traceback']=traceback.format_exc();raise
finally:
 r['seconds']=time.perf_counter()-started;save()
