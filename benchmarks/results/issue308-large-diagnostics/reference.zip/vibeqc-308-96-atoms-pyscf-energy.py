"""Independent CPU DF energy check, separate from diagnostic GPU timings."""
from pathlib import Path
import hashlib,json,os,time,traceback
from pyscf import gto,scf,lib
from benchmarks._cases import benchmark_cases
lib.num_threads(1)
case=benchmark_cases()['water-32mer-4s4-def2-svp-spherical']
root=Path('/tmp/vibeqc-308-96-atoms-pyscf-energy');root.mkdir(exist_ok=False)
r={'schema':'vibeqc.issue308.independent-energy.v1','status':'running','atoms':96,'ao_count':768,'basis':'def2-svp','auxiliary_basis':'def2-svp','method':'RHF','engine':'PySCF','cpu_threads':1,'energy_tolerance':1e-12,'gradient_tolerance':1e-10,'iterations':[]}
def save():(root/'result.json').write_text(json.dumps(r,indent=2)+'\n')
save()
started=time.perf_counter()
try:
 mol=gto.M(atom=case.atoms,basis='def2-svp',unit='Bohr',cart=False,verbose=4,output=str(root/'pyscf.log'),max_memory=8000)
 assert mol.natm==96 and mol.nao_nr()==768
 mf=scf.RHF(mol).density_fit(auxbasis='def2-svp')
 mf.conv_tol=1e-12;mf.conv_tol_grad=1e-10;mf.max_cycle=100;mf.max_memory=8000
 def callback(env):
  r['iterations'].append({'cycle':int(env['cycle']),'energy':float(env['e_tot']),'gradient_norm':float(env['norm_gorb']),'density_change':float(env['norm_ddm'])});save()
 mf.callback=callback
 r['energy']=float(mf.kernel());r['converged']=bool(mf.converged)
 r['status']='passed' if mf.converged else 'failed'
except Exception as error:
 r['status']='failed';r['error']=repr(error);r['traceback']=traceback.format_exc();raise
finally:
 r['seconds']=time.perf_counter()-started;save()
